import 'package:flutter/material.dart';
import 'book.dart';

class BookList extends StatelessWidget {
  const BookList({super.key});

  final List<Book> books = const [
    Book(
      coverImagePath: 'assets/images/book1.jpg',
      title: 'All Fours',
      author: 'Miranda July',
      price: 1250.0,
    ),
    Book(
      coverImagePath: 'assets/images/book2.jpg',
      title: 'James',
      author: 'Percival Everett',
      price: 1800.0,
    ),
    Book(
      coverImagePath: 'assets/images/book3.jpg',
      title: 'Good Material',
      author: 'Dolly Alderton',
      price: 2500.0,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Online Book Store'),
          backgroundColor: Theme.of(context).colorScheme.primary,
        ),
        body: ListView.builder(
          itemCount: books.length,
          itemBuilder: (context, index) => books[index],
        ),
      ),
    );
  }
}
